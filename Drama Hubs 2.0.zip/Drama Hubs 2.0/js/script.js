// DOM Elements
const dramaGrid = document.getElementById('all-dramas');
const trendingDramasContainer = document.getElementById('trending-dramas');
const topPicksTrack = document.getElementById('top-picks-track'); // Carousel track for Top Picks
const upcomingDramasTrack = document.getElementById('upcoming-dramas'); // Carousel track for Upcoming Dramas
const heroSlider = document.querySelector('.hero-slider');
const heroDotsContainer = document.querySelector('.hero-dots');
const slides = document.querySelectorAll('.slide');

// Carousel specific buttons (Top Picks - generic)
const topPicksPrevBtn = document.querySelector('.carousel-section:nth-of-type(2) .carousel-btn.prev'); // Targeting the first carousel's prev
const topPicksNextBtn = document.querySelector('.carousel-section:nth-of-type(2) .carousel-btn.next'); // Targeting the first carousel's next

// Carousel specific buttons (Upcoming Dramas - with IDs)
const upcomingPrevBtn = document.getElementById('upcoming-prev');
const upcomingNextBtn = document.getElementById('upcoming-next');

const searchToggle = document.getElementById('search-toggle');
const searchBox = document.querySelector('.search-box');
const countryFilter = document.getElementById('country-filter');
const genreFilter = document.getElementById('genre-filter');
const yearFilter = document.getElementById('year-filter');
const sortBy = document.getElementById('sort-by');
const resetFiltersBtn = document.getElementById('reset-filters');
const prevPageBtn = document.getElementById('prev-page');
const nextPageBtn = document.getElementById('next-page');
const pageNumbersSpan = document.getElementById('page-numbers');


// Modal Elements (New)
const messageModal = document.getElementById('messageModal');
const modalMessage = document.getElementById('modalMessage');
const modalCloseButton = document.querySelector('.modal .close-button');
const modalOkButton = document.getElementById('modalOkButton');


// Drama Data (would normally come from an API or JSON file)
let dramas = [];
let filteredDramas = [];
let currentPage = 1;
const dramasPerPage = 12;
let slideIndex = 0;
let slideInterval; // To store the interval for hero slider


// --- Utility Functions ---

/**
 * Displays a modal message to the user.
 * @param {string} message - The message to display.
 * @param {string} type - Optional: 'success', 'error', 'info'. (Currently only displays text)
 */
function showModalMessage(message, type = 'info') {
    modalMessage.textContent = message;
    // You could add classes to modalMessage based on type for different styling
    // e.g., modalMessage.className = `modal-message ${type}`;
    messageModal.classList.add('active');
}

/**
 * Closes the modal message.
 */
function closeModalMessage() {
    messageModal.classList.remove('active');
}

// Add event listeners for modal close buttons
if (modalCloseButton) {
    modalCloseButton.addEventListener('click', closeModalMessage);
}
if (modalOkButton) {
    modalOkButton.addEventListener('click', closeModalMessage);
}
// Close modal if clicked outside content
if (messageModal) {
    messageModal.addEventListener('click', (e) => {
        if (e.target === messageModal) {
            closeModalMessage();
        }
    });
}


/**
 * Fetches drama data from dramas.json.
 */
async function fetchDramaData() {
    const possiblePaths = [
        '../dramas.json', // Common if js/ is a subdirectory
        'dramas.json',    // Common if script.js and dramas.json are in the same directory
        '/dramas.json'    // Absolute path from root, sometimes works
    ];

    let dataFetched = false;
    for (const path of possiblePaths) {
        try {
            console.log(`Attempting to fetch dramas.json from: ${path}`);
            const response = await fetch(path);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status} from ${path}`);
            }
            dramas = await response.json();
            filteredDramas = [...dramas]; // Initialize filtered dramas
            initializeApp();
            dataFetched = true;
            console.log(`Successfully loaded dramas.json from: ${path}`);
            break; // Exit loop if successful
        } catch (error) {
            console.error(`Failed to load dramas.json from ${path}:`, error);
        }
    }

    if (!dataFetched) {
        showModalMessage('Failed to load drama data. Please ensure "dramas.json" is in the correct location (e.g., the same folder as your HTML files, or in a "js" folder if "script.js" is also there).');
    }
}

/**
 * Initializes the application by rendering content and setting up listeners.
 */
function initializeApp() {
    if (document.body.classList.contains('index-page')) { // Check if on index.html
        renderTrendingDramas();
        renderTopPicks();
        renderUpcomingDramas();
        setupHeroSlider();
    }

    if (document.body.classList.contains('dramas-page')) { // Check if on dramas.html
        renderDramas();
        setupFilters();
        setupPagination();
    }

    if (document.body.classList.contains('cast-page')) { // Check if on cast.html
        renderAllCast();
    }

    if (document.body.classList.contains('reviews-page')) { // Check if on reviews.html
        renderAllReviews();
        setupReviewForm();
    }

    if (document.body.classList.contains('drama-detail-page')) { // Check if on drama-detail.html
        const urlParams = new URLSearchParams(window.location.search);
        const dramaId = urlParams.get('id');
        if (dramaId) {
            renderDramaDetail(dramaId);
        } else {
            console.warn('No drama ID found in URL for detail page.');
            showModalMessage('Drama not found. Please select a drama from the list.');
        }
    }
}


/**
 * Creates a drama card HTML element.
 * @param {Object} drama - The drama object.
 * @returns {HTMLElement} - The created drama card element.
 */
function createDramaCard(drama) {
    const dramaCard = document.createElement('div');
    dramaCard.classList.add('drama-card');
    dramaCard.innerHTML = `
        <a href="drama-detail.html?id=${drama.id}">
            <img src="${drama.poster}" alt="${drama.title} Poster" onerror="this.onerror=null;this.src='https://placehold.co/300x450/cccccc/333333?text=No+Image';">
            <div class="drama-card-content">
                <h3>${drama.title}</h3>
                <p>${drama.country} | ${drama.year}</p>
                <p class="rating"><i class="fas fa-star"></i> ${drama.rating}</p>
            </div>
        </a>
    `;
    return dramaCard;
}

/**
 * Renders dramas to the main grid (for dramas.html).
 */
function renderDramas() {
    if (!dramaGrid) return; // Ensure element exists

    dramaGrid.innerHTML = ''; // Clear existing dramas
    const start = (currentPage - 1) * dramasPerPage;
    const end = start + dramasPerPage;
    const paginatedDramas = filteredDramas.slice(start, end);

    if (paginatedDramas.length === 0) {
        dramaGrid.innerHTML = '<p class="text-center">No dramas found matching your criteria.</p>';
    } else {
        paginatedDramas.forEach(drama => {
            dramaGrid.appendChild(createDramaCard(drama));
        });
    }
    updatePaginationControls();
}

/**
 * Renders trending dramas in the dedicated section.
 */
function renderTrendingDramas() {
    if (!trendingDramasContainer) return;

    trendingDramasContainer.innerHTML = '';
    // Sort by popularity and take top 4
    const trending = [...dramas].sort((a, b) => b.popularity - a.popularity).slice(0, 4);
    trending.forEach(drama => {
        trendingDramasContainer.appendChild(createDramaCard(drama));
    });
}

/**
 * Renders top picks in the carousel.
 */
function renderTopPicks() {
    if (!topPicksTrack) return;

    topPicksTrack.innerHTML = '';
    // Sort by rating and take top 8 for carousel
    const topPicks = [...dramas].sort((a, b) => b.rating - a.rating).slice(0, 8);
    topPicks.forEach(drama => {
        const dramaCard = createDramaCard(drama);
        dramaCard.style.minWidth = '250px'; // Ensure cards take up space in carousel
        dramaCard.style.marginRight = '20px'; // Add spacing between cards
        topPicksTrack.appendChild(dramaCard);
    });

    // Setup carousel navigation for Top Picks
    setupCarousel(topPicksTrack, topPicksPrevBtn, topPicksNextBtn);
}


/**
 * Renders upcoming dramas in the carousel.
 */
function renderUpcomingDramas() {
    if (!upcomingDramasTrack) return;

    upcomingDramasTrack.innerHTML = '';
    // Filter for dramas released in the current or future year (example logic)
    const currentYear = new Date().getFullYear();
    const upcoming = dramas.filter(d => parseInt(d.year) >= currentYear && d.status === 'Upcoming')
                             .sort((a, b) => new Date(a.releaseDate) - new Date(b.releaseDate))
                             .slice(0, 6); // Limit to 6 upcoming items for example

    if (upcoming.length === 0) {
        upcomingDramasTrack.innerHTML = '<p class="text-center">No upcoming dramas at the moment.</p>';
        return;
    }

    upcoming.forEach(drama => {
        const upcomingItem = document.createElement('div');
        upcomingItem.classList.add('upcoming-item');
        upcomingItem.innerHTML = `
            <a href="drama-detail.html?id=${drama.id}">
                <img src="${drama.poster}" alt="${drama.title} Poster" onerror="this.onerror=null;this.src='https://placehold.co/300x200/cccccc/333333?text=No+Image';">
                <h4>${drama.title}</h4>
                <p>Release: ${drama.releaseDate || drama.year}</p>
            </a>
        `;
        upcomingDramasTrack.appendChild(upcomingItem);
    });

    // Setup carousel navigation for Upcoming Dramas
    setupCarousel(upcomingDramasTrack, upcomingPrevBtn, upcomingNextBtn);
}


/**
 * Sets up generic carousel functionality for a given track and its buttons.
 * @param {HTMLElement} trackElement - The carousel track element.
 * @param {HTMLElement} prevButton - The previous button for this carousel.
 * @param {HTMLElement} nextButton - The next button for this carousel.
 */
function setupCarousel(trackElement, prevButton, nextButton) {
    if (!trackElement || !prevButton || !nextButton) return;

    let carouselScrollPosition = 0;
    const itemWidth = trackElement.firstElementChild ? trackElement.firstElementChild.offsetWidth + 20 : 0; // Item width + margin
    // console.log(`Carousel: ${trackElement.id}, Item Width: ${itemWidth}`); // Debugging

    const updateCarouselButtons = () => {
        // Disable prev button if at the beginning
        prevButton.disabled = carouselScrollPosition <= 0;

        // Disable next button if at the end or content is smaller than container
        const maxScroll = trackElement.scrollWidth - trackElement.offsetWidth;
        nextButton.disabled = carouselScrollPosition >= maxScroll || maxScroll <= 0;
    };

    // Initial button state
    updateCarouselButtons();

    nextButton.addEventListener('click', () => {
        const scrollAmount = itemWidth * Math.min(2, Math.floor(trackElement.offsetWidth / itemWidth)); // Scroll by 2 items or max visible items
        carouselScrollPosition += scrollAmount;
        const maxScroll = trackElement.scrollWidth - trackElement.offsetWidth;
        if (carouselScrollPosition > maxScroll) {
            carouselScrollPosition = maxScroll;
        }
        trackElement.style.transform = `translateX(-${carouselScrollPosition}px)`;
        updateCarouselButtons();
    });

    prevButton.addEventListener('click', () => {
        const scrollAmount = itemWidth * Math.min(2, Math.floor(trackElement.offsetWidth / itemWidth)); // Scroll by 2 items or max visible items
        carouselScrollPosition -= scrollAmount;
        if (carouselScrollPosition < 0) {
            carouselScrollPosition = 0;
        }
        trackElement.style.transform = `translateX(-${carouselScrollPosition}px)`;
        updateCarouselButtons();
    });

    // Recalculate on window resize
    window.addEventListener('resize', () => {
        const maxScroll = trackElement.scrollWidth - trackElement.offsetWidth;
        if (carouselScrollPosition > maxScroll) {
            carouselScrollPosition = maxScroll > 0 ? maxScroll : 0;
            trackElement.style.transform = `translateX(-${carouselScrollPosition}px)`;
        }
        updateCarouselButtons();
    });
}


/**
 * Sets up the hero image slider.
 */
function setupHeroSlider() {
    if (!heroSlider || slides.length === 0) return;

    // Create dots
    if (heroDotsContainer) {
        heroDotsContainer.innerHTML = ''; // Clear existing dots
        slides.forEach((_, index) => {
            const dot = document.createElement('div');
            dot.classList.add('hero-dot');
            if (index === 0) dot.classList.add('active');
            dot.addEventListener('click', () => {
                moveToSlide(index);
                resetSlideInterval();
            });
            heroDotsContainer.appendChild(dot);
        });
    }

    const updateDots = () => {
        if (heroDotsContainer) {
            document.querySelectorAll('.hero-dot').forEach((dot, index) => {
                dot.classList.toggle('active', index === slideIndex);
            });
        }
    };

    const moveToSlide = (index) => {
        if (heroSlider) {
            slideIndex = index;
            if (slideIndex >= slides.length) slideIndex = 0;
            if (slideIndex < 0) slideIndex = slides.length - 1;
            heroSlider.style.transform = `translateX(-${slideIndex * 100}%)`;
            updateDots();
        }
    };

    const nextSlide = () => {
        moveToSlide(slideIndex + 1);
    };

    const resetSlideInterval = () => {
        clearInterval(slideInterval);
        slideInterval = setInterval(nextSlide, 5000); // Change slide every 5 seconds
    };

    // Initialize slider and start interval
    moveToSlide(0);
    resetSlideInterval();

    // Pause on hover
    if (heroSlider) {
        heroSlider.addEventListener('mouseenter', () => clearInterval(slideInterval));
        heroSlider.addEventListener('mouseleave', resetSlideInterval);
    }
}


/**
 * Populates filter options dynamically and sets up change listeners.
 */
function setupFilters() {
    if (!countryFilter || !genreFilter || !yearFilter) return;

    // Populate Country Filter
    const countries = [...new Set(dramas.map(d => d.country))].sort();
    countryFilter.innerHTML = '<option value="">All Countries</option>';
    countries.forEach(country => {
        countryFilter.innerHTML += `<option value="${country}">${country}</option>`;
    });

    // Populate Genre Filter
    const genres = [...new Set(dramas.flatMap(d => d.genres))].sort();
    genreFilter.innerHTML = '<option value="">All Genres</option>';
    genres.forEach(genre => {
        genreFilter.innerHTML += `<option value="${genre}">${genre}</option>`;
    });

    // Populate Year Filter (e.g., last 10 years + all years)
    const currentYear = new Date().getFullYear();
    const years = [...new Set(dramas.map(d => parseInt(d.year)))].filter(Boolean).sort((a, b) => b - a);
    yearFilter.innerHTML = '<option value="">All Years</option>';
    years.forEach(year => {
        yearFilter.innerHTML += `<option value="${year}">${year}</option>`;
    });

    // Add event listeners to filters and sort
    countryFilter.addEventListener('change', applyFiltersAndSort);
    genreFilter.addEventListener('change', applyFiltersAndSort);
    yearFilter.addEventListener('change', applyFiltersAndSort);
    sortBy.addEventListener('change', applyFiltersAndSort);
    resetFiltersBtn.addEventListener('click', resetAllFilters);
}

/**
 * Applies active filters and sorting to the drama list.
 */
function applyFiltersAndSort() {
    currentPage = 1; // Reset to first page on filter/sort change

    const selectedCountry = countryFilter.value;
    const selectedGenre = genreFilter.value;
    const selectedYear = yearFilter.value;
    const selectedSortBy = sortBy.value;

    filteredDramas = dramas.filter(drama => {
        const matchesCountry = !selectedCountry || drama.country === selectedCountry;
        const matchesGenre = !selectedGenre || drama.genres.includes(selectedGenre);
        const matchesYear = !selectedYear || drama.year === selectedYear;
        return matchesCountry && matchesGenre && matchesYear;
    });

    // Apply sorting
    if (selectedSortBy === 'title-asc') {
        filteredDramas.sort((a, b) => a.title.localeCompare(b.title));
    } else if (selectedSortBy === 'title-desc') {
        filteredDramas.sort((a, b) => b.title.localeCompare(a.title));
    } else if (selectedSortBy === 'rating-desc') {
        filteredDramas.sort((a, b) => b.rating - a.rating);
    } else if (selectedSortBy === 'rating-asc') {
        filteredDramas.sort((a, b) => a.rating - b.rating);
    } else if (selectedSortBy === 'year-desc') {
        filteredDramas.sort((a, b) => b.year - a.year);
    } else if (selectedSortBy === 'year-asc') {
        filteredDramas.sort((a, b) => a.year - b.year);
    }

    renderDramas();
}

/**
 * Resets all filters to default.
 */
function resetAllFilters() {
    countryFilter.value = '';
    genreFilter.value = '';
    yearFilter.value = '';
    sortBy.value = 'title-asc'; // Default sort
    applyFiltersAndSort();
}

/**
 * Sets up pagination controls.
 */
function setupPagination() {
    if (!prevPageBtn || !nextPageBtn || !pageNumbersSpan) return;

    prevPageBtn.addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            renderDramas();
        }
    });

    nextPageBtn.addEventListener('click', () => {
        const totalPages = Math.ceil(filteredDramas.length / dramasPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            renderDramas();
        }
    });
}

/**
 * Updates the state of pagination buttons and page number display.
 */
function updatePaginationControls() {
    if (!prevPageBtn || !nextPageBtn || !pageNumbersSpan) return;

    const totalPages = Math.ceil(filteredDramas.length / dramasPerPage);
    pageNumbersSpan.textContent = `Page ${currentPage} of ${totalPages}`;

    prevPageBtn.disabled = currentPage === 1;
    nextPageBtn.disabled = currentPage === totalPages || totalPages === 0;

    // If there are no dramas, disable both buttons and show page 0 of 0
    if (filteredDramas.length === 0) {
        prevPageBtn.disabled = true;
        nextPageBtn.disabled = true;
        pageNumbersSpan.textContent = 'Page 0 of 0';
    }
}


/**
 * Renders the drama detail page based on the drama ID.
 * @param {string} dramaId - The ID of the drama to render.
 */
function renderDramaDetail(dramaId) {
    const drama = dramas.find(d => d.id === dramaId);

    if (!drama) {
        showModalMessage('Drama details not found.');
        return;
    }

    document.title = `${drama.title} | Thai & Chinese Drama Hub`;

    document.getElementById('detail-poster').src = drama.poster;
    document.getElementById('detail-poster').alt = `${drama.title} Poster`;
    document.getElementById('detail-title').textContent = drama.title;
    document.getElementById('detail-country').innerHTML = `<i class="fas fa-globe"></i> ${drama.country}`;
    document.getElementById('detail-year').innerHTML = `<i class="fas fa-calendar-alt"></i> ${drama.year}`;
    document.getElementById('detail-episodes').innerHTML = `<i class="fas fa-film"></i> ${drama.episodes} Episodes`;
    document.getElementById('detail-status').innerHTML = `<i class="fas fa-check-circle"></i> ${drama.status}`;
    document.getElementById('detail-rating').innerHTML = `<i class="fas fa-star"></i> ${drama.rating}`;
    document.getElementById('detail-popularity').innerHTML = `<i class="fas fa-chart-line"></i> ${drama.popularity}%`;
    document.getElementById('detail-genres').innerHTML = `<i class="fas fa-tags"></i> ${drama.genres.join(', ')}`;
    document.getElementById('detail-description').textContent = drama.description;
    document.getElementById('watch-trailer-btn').href = drama.trailer;

    // Set up tabs
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(btn => {
        btn.addEventListener('click', switchTab);
    });
    // Set default active tab
    if (tabButtons.length > 0) {
        tabButtons[0].click(); // Activate the first tab (Cast) by default
    }


    renderCast(drama.cast);
    renderEpisodes(drama.episodes);
    renderReviews(drama.reviews);
    renderGallery(drama.gallery);
    renderRecommendedDramas(drama.id, drama.genres[0]); // Recommend based on the first genre
}


/**
 * Renders cast members on the drama detail page.
 * @param {Array<Object>} cast - Array of cast members.
 */
function renderCast(cast) {
    const castContainer = document.getElementById('cast-grid-detail'); // Specific ID for detail page cast
    if (!castContainer) return;
    castContainer.innerHTML = '';
    cast.forEach(member => {
        const castCard = document.createElement('div');
        castCard.classList.add('cast-card');
        castCard.innerHTML = `
            <img src="${member.image}" alt="${member.name}" onerror="this.onerror=null;this.src='https://placehold.co/150x200/cccccc/333333?text=No+Image';">
            <div class="cast-card-content">
                <h3>${member.name}</h3>
                <p>${member.role || 'Various Roles'}</p>
            </div>
        `;
        castContainer.appendChild(castCard);
    });
}

/**
 * Renders episode list on the drama detail page.
 * @param {Array<Object>} episodes - Array of episodes.
 */
function renderEpisodes(episodes) {
    const episodesContainer = document.getElementById('episode-list');
    if (!episodesContainer) return;
    episodesContainer.innerHTML = '';
    if (episodes && episodes.length > 0) {
        episodes.forEach(episode => {
            const episodeItem = document.createElement('div');
            episodeItem.classList.add('episode-item');
            episodeItem.innerHTML = `
                <img src="${episode.thumbnail}" alt="Episode ${episode.number} Thumbnail" onerror="this.onerror=null;this.src='https://placehold.co/320x180/cccccc/333333?text=Episode+Thumbnail';">
                <div class="episode-content">
                    <h4>Episode ${episode.number}: ${episode.title}</h4>
                    <p>Released: ${episode.date}</p>
                    <p>${episode.description}</p>
                    <a href="${episode.watchLink}" class="btn btn-secondary" target="_blank">Watch Episode</a>
                </div>
            `;
            episodesContainer.appendChild(episodeItem);
        });
    } else {
        episodesContainer.innerHTML = '<p class="text-center">No episode information available.</p>';
    }
}

/**
 * Renders reviews on the drama detail page.
 * @param {Array<Object>} reviews - Array of reviews.
 */
function renderReviews(reviews) {
    const reviewsContainer = document.getElementById('reviews-grid-detail'); // Specific ID for detail page reviews
    if (!reviewsContainer) return;
    reviewsContainer.innerHTML = '';
    if (reviews && reviews.length > 0) {
        reviews.forEach(review => {
            const reviewItem = document.createElement('div');
            reviewItem.classList.add('review-item');
            reviewItem.innerHTML = `
                <div class="rating">${'⭐'.repeat(review.rating)}</div>
                <h4>${review.title}</h4>
                <p>"${review.content}"</p>
                <div class="author-info">
                    <span>- ${review.author}</span>
                    <span>on <a href="drama-detail.html?id=${dramas.find(d => d.title === review.dramaTitle)?.id || '#'}">${review.dramaTitle || ''}</a></span>
                    <span>${review.date}</span>
                </div>
            `;
            reviewsContainer.appendChild(reviewItem);
        });
    } else {
        reviewsContainer.innerHTML = '<p class="text-center">No reviews yet. Be the first to add one!</p>';
    }
}

/**
 * Renders gallery images on the drama detail page.
 * @param {Array<string>} galleryImages - Array of image URLs.
 */
function renderGallery(galleryImages) {
    const galleryContainer = document.getElementById('gallery-grid');
    if (!galleryContainer) return;
    galleryContainer.innerHTML = '';
    if (galleryImages && galleryImages.length > 0) {
        galleryImages.forEach(image => {
            const galleryItem = document.createElement('div');
            galleryItem.classList.add('gallery-item');
            galleryItem.innerHTML = `<img src="${image}" alt="Gallery image" onerror="this.onerror=null;this.src='https://placehold.co/800x500/cccccc/333333?text=No+Image';">`;
            galleryContainer.appendChild(galleryItem);
        });
    } else {
        galleryContainer.innerHTML = '<p class="text-center">No gallery images available.</p>';
    }
}

/**
 * Renders recommended dramas on the detail page.
 * @param {string} currentDramaId - The ID of the current drama to exclude.
 * @param {string} genre - The primary genre to recommend by.
 */
function renderRecommendedDramas(currentDramaId, genre) {
    const recommendedContainer = document.getElementById('recommended-dramas');
    if (!recommendedContainer) return;

    // Get dramas with the same genre, excluding the current one, and sort by rating
    const recommended = dramas
        .filter(d => d.id !== currentDramaId && d.genres.includes(genre))
        .sort((a, b) => b.rating - a.rating)
        .slice(0, 4); // Show top 4 recommended

    recommendedContainer.innerHTML = ''; // Clear existing
    if (recommended.length === 0) {
        recommendedContainer.innerHTML = '<p class="text-center">No recommendations available.</p>';
        return;
    }

    recommended.forEach(drama => {
        const dramaCard = createDramaCard(drama);
        recommendedContainer.appendChild(dramaCard);
    });
}

/**
 * Switches between tabs on the drama detail page.
 * @param {Event} e - The click event.
 */
function switchTab(e) {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => btn.classList.remove('active'));
    tabContents.forEach(content => content.classList.remove('active'));

    e.target.classList.add('active');
    const tabId = e.target.getAttribute('data-tab');
    document.getElementById(`${tabId}-tab`).classList.add('active');
}

/**
 * Renders all cast members on the cast.html page.
 */
function renderAllCast() {
    const allCastGrid = document.getElementById('all-cast');
    if (!allCastGrid) return;
    allCastGrid.innerHTML = '';

    // Collect all unique cast members from all dramas
    const allCastMembers = [];
    const castNames = new Set(); // To keep track of unique names

    dramas.forEach(drama => {
        drama.cast.forEach(member => {
            if (!castNames.has(member.name)) {
                allCastMembers.push(member);
                castNames.add(member.name);
            }
        });
    });

    // Sort alphabetically by name
    allCastMembers.sort((a, b) => a.name.localeCompare(b.name));

    allCastMembers.forEach(member => {
        const castCard = document.createElement('div');
        castCard.classList.add('cast-card');
        castCard.innerHTML = `
            <img src="${member.image}" alt="${member.name}" onerror="this.onerror=null;this.src='https://placehold.co/150x200/cccccc/333333?text=No+Image';">
            <div class="cast-card-content">
                <h3>${member.name}</h3>
                <p>${member.role || 'Various Roles'}</p>
            </div>
        `;
        allCastGrid.appendChild(castCard);
    });
}


/**
 * Renders all reviews on the reviews.html page.
 */
function renderAllReviews() {
    const allReviewsGrid = document.getElementById('all-reviews');
    if (!allReviewsGrid) return;
    allReviewsGrid.innerHTML = '';

    const allReviews = [];
    dramas.forEach(drama => {
        if (drama.reviews) { // Ensure reviews array exists
            drama.reviews.forEach(review => {
                // Add drama title to review object for display
                allReviews.push({ ...review, dramaTitle: drama.title });
            });
        }
    });

    // Sort by date (most recent first)
    allReviews.sort((a, b) => new Date(b.date) - new Date(a.date));

    if (allReviews.length === 0) {
        allReviewsGrid.innerHTML = '<p class="text-center">No reviews available yet.</p>';
        return;
    }

    allReviews.forEach(review => {
        const reviewItem = document.createElement('div');
        reviewItem.classList.add('review-item');
        reviewItem.innerHTML = `
            <div class="rating">${'⭐'.repeat(review.rating)}</div>
            <h4>${review.title}</h4>
            <p>"${review.content}"</p>
            <div class="author-info">
                <span>- ${review.author}</span>
                <span>on <a href="drama-detail.html?id=${dramas.find(d => d.title === review.dramaTitle)?.id || '#'}">${review.dramaTitle || ''}</a></span>
                <span>${review.date}</span>
            </div>
        `;
        allReviewsGrid.appendChild(reviewItem);
    });
}

/**
 * Sets up the review submission form.
 */
function setupReviewForm() {
    const reviewForm = document.getElementById('review-form');
    if (!reviewForm) return;

    // Populate drama options
    const dramaSelect = document.getElementById('review-drama');
    if (dramaSelect) {
        dramas.sort((a, b) => a.title.localeCompare(b.title)).forEach(drama => {
            const option = document.createElement('option');
            option.value = drama.id;
            option.textContent = drama.title;
            dramaSelect.appendChild(option);
        });
    }

    reviewForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent default form submission

        const dramaId = document.getElementById('review-drama').value;
        const author = document.getElementById('reviewer-name').value.trim();
        const rating = parseInt(document.getElementById('review-rating').value);
        const title = document.getElementById('review-title').value.trim();
        const content = document.getElementById('review-content').value.trim();

        if (!dramaId || !author || !rating || !title || !content) {
            showModalMessage('Please fill in all fields before submitting your review.');
            return;
        }

        const newReview = {
            author: author,
            date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
            rating: rating,
            title: title,
            content: content
        };

        // Find the drama and add the review (this would ideally be sent to a backend)
        const dramaToUpdate = dramas.find(d => d.id === dramaId);
        if (dramaToUpdate) {
            if (!dramaToUpdate.reviews) {
                dramaToUpdate.reviews = [];
            }
            dramaToUpdate.reviews.unshift(newReview); // Add to the beginning
            console.log('New review added:', newReview);
            // In a real application, you'd send this to a server to save
            showModalMessage('Your review has been submitted successfully! (Note: In a real application, this would be saved to a database.)');
            reviewForm.reset(); // Clear the form
            renderAllReviews(); // Re-render reviews to show the new one
        } else {
            showModalMessage('Selected drama not found.');
        }
    });
}


// --- Event Listeners ---

// Search toggle
if (searchToggle && searchBox) {
    searchToggle.addEventListener('click', () => {
        searchBox.classList.toggle('active');
        if (searchBox.classList.contains('active')) {
            searchBox.querySelector('input').focus();
        }
    });
}


// Initial data fetch and app initialization
document.addEventListener('DOMContentLoaded', fetchDramaData);
