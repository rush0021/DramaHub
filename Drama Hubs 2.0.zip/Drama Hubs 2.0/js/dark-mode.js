// Dark Mode Toggle
const darkModeToggle = document.getElementById('dark-mode-toggle');
const darkModeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

// Check for saved user preference or use system preference
function checkDarkModePreference() {
    const userPreference = localStorage.getItem('darkMode');
    const systemPreference = darkModeMediaQuery.matches;
    
    // If user has a preference, use it. Otherwise, use system preference.
    if (userPreference === 'enabled' || (userPreference === null && systemPreference)) {
        enableDarkMode();
    } else {
        disableDarkMode();
    }
}

// Enable dark mode
function enableDarkMode() {
    document.body.classList.add('dark-mode');
    localStorage.setItem('darkMode', 'enabled');
    if (darkModeToggle) { // Check if the toggle button exists on the page
        darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>'; // Change icon to sun
    }
}

// Disable dark mode
function disableDarkMode() {
    document.body.classList.remove('dark-mode');
    localStorage.setItem('darkMode', 'disabled');
    if (darkModeToggle) { // Check if the toggle button exists on the page
        darkModeToggle.innerHTML = '<i class="fas fa-moon"></i>'; // Change icon to moon
    }
}

// Toggle dark mode
function toggleDarkMode() {
    if (document.body.classList.contains('dark-mode')) {
        disableDarkMode();
    } else {
        enableDarkMode();
    }
}

// Listen for system preference changes (only apply if user hasn't set a preference)
darkModeMediaQuery.addListener(e => {
    const userPreference = localStorage.getItem('darkMode');
    if (userPreference === null) { // Only change if user hasn't manually set a preference
        if (e.matches) {
            enableDarkMode();
        } else {
            disableDarkMode();
        }
    }
});

// Event listener for the dark mode toggle button
if (darkModeToggle) {
    darkModeToggle.addEventListener('click', toggleDarkMode);
}

// Initialize dark mode on page load
document.addEventListener('DOMContentLoaded', checkDarkModePreference);
